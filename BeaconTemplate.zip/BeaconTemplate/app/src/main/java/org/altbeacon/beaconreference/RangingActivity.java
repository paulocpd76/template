package org.altbeacon.beaconreference;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import android.widget.EditText;

import org.altbeacon.beacon.AltBeacon;
import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconConsumer;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.BeaconTransmitter;
import org.altbeacon.beacon.Identifier;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;
//

import android.bluetooth.BluetoothAdapter;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import Proxemic.Dilmo;
import Proxemic.ProxZone;

public class RangingActivity extends Activity implements BeaconConsumer {
    protected static final String TAG = "RangingActivity";
    private BeaconManager beaconManager = BeaconManager.getInstanceForApplication(this);
    String name,keyUser;
   //public String mobile;
   String lastInsertId;
    MediaPlayer mediaPlayer;


    private BluetoothAdapter blVer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranging);
        //onCreateUserBeacon();

        // Cash Paremeters
        Intent intent=getIntent();
        name= intent.getStringExtra("name".trim());
        keyUser= intent.getStringExtra("keyUser");
        Log.d("name" ,name+"-"+keyUser);
        //New beacon
        blVer = BluetoothAdapter.getDefaultAdapter();
        onCreateUserBeacon2(name);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
        beaconManager.unbind(this);



        //

        //
    }

    @Override
    protected void onResume() {
        super.onResume();
        beaconManager.bind(this);
    }
/*
    @Override
    public void onBeaconServiceConnect() {

        RangeNotifier rangeNotifier = new RangeNotifier() {
            @Override
            public void didRangeBeaconsInRegion(Collection<Beacon> beacons, Region region) {
                if (beacons.size() > 0) {

                    Log.d(TAG, "didRangeBeaconsInRegion called with beacon count:  "+beacons.size());
                    Beacon firstBeacon = beacons.iterator().next();
                    logToDisplay("The first beacon " + firstBeacon.toString() + " is about " + firstBeacon.getDistance() + " meters away.");

                    Log.d("m1","distance "+firstBeacon.getDistance());

                }
            }

        };
        try {
            beaconManager.startRangingBeaconsInRegion(new Region("myRangingUniqueId", null, null, null));
            beaconManager.addRangeNotifier(rangeNotifier);
            beaconManager.startRangingBeaconsInRegion(new Region("myRangingUniqueId", null, null, null));
            beaconManager.addRangeNotifier(rangeNotifier);
        } catch (RemoteException e) {   }
    }

    private void logToDisplay(final String line) {
        runOnUiThread(new Runnable() {
            public void run() {
                EditText editText = (EditText)RangingActivity.this.findViewById(R.id.rangingText);
                editText.append(line+"\n");
            }
        });
    }

  */
@Override
public void onBeaconServiceConnect() {

    RangeNotifier rangeNotifier = new RangeNotifier() {
        @Override
        public void didRangeBeaconsInRegion(Collection<Beacon> beacons, Region region) {
            ProxZone p = new ProxZone(0.5D, 1.0D, 4.0D, 50.0D);
            Dilmo dilmo = new Dilmo(p);

            if (beacons.size() > 0) {
               Log.d(TAG, "didRangeBeaconsInRegion called with beacon count:  "+beacons.size());
                Beacon firstBeacon = beacons.iterator().next();
                //logToDisplay("The first beacon " + firstBeacon.toString() + " is about " + firstBeacon.getDistance() + " meters away.");
                Log.d("m1","distance "+firstBeacon.getDistance());
                //
                for (Beacon b:beacons) {
                    String receivedString ;
                    byte[] bytes = b.getId1().toByteArray();
                    receivedString = null;
                    try {
                        receivedString = new String(bytes, 0, bytes.length, "ASCII");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    //Distance
                    double distance1 = b.getDistance();
                    String distance = String.valueOf(Math.round(distance1 * 100.0) / 100.0);
                    String uuid = receivedString;
                    //logToDisplay(uuid+"="+distance);
                    dilmo.setProxemicDistance(distance1);

                    if(dilmo.getProxemicZoneByDistance().equals("intimiZone")||dilmo.getProxemicZoneByDistance().equals("personalZone") ){
                    dilmo.setProxemicDI(uuid,distance1);

                     getInfetcted(uuid);
                     System.out.println("rinf"+lastInsertId);
                     if(lastInsertId==null){logToDisplay("free");}
                     else {
                         if(lastInsertId.equals("infected"))logToDisplay(lastInsertId+":"+dilmo.getProxemicDI(uuid));
                         else logToDisplay("free");

                     }
                   // logToDisplay(uuid+":"+dilmo.getProxemicDI(uuid));

                    }
                    else {
                        logToDisplay("outSide");

                    }
                }


                //

            }
        }

    };
    try {
        beaconManager.startRangingBeaconsInRegion(new Region("myRangingUniqueId", null, null, null));
        beaconManager.addRangeNotifier(rangeNotifier);
        beaconManager.startRangingBeaconsInRegion(new Region("myRangingUniqueId", null, null, null));
        beaconManager.addRangeNotifier(rangeNotifier);
    } catch (RemoteException e) {   }
}

    private void logToDisplay(final String line) {
        runOnUiThread(new Runnable() {
            public void run() {
                EditText editText = (EditText)RangingActivity.this.findViewById(R.id.rangingText);
                editText.append(line+"\n");
            }
        });
    }

    private void onCreateUserBeacon(){

        Beacon beacon = new Beacon.Builder()
                .setId1("3f234454-cf6d-4a0f-adf2-f4911ba9ffa7")
                .setId2("1")
                .setId3("2")
                .setManufacturer(0x0118)
                .setTxPower(-59)
                .setDataFields(Arrays.asList(new Long[] {0l}))
                .build();

        BeaconParser beaconParser = new BeaconParser()
                .setBeaconLayout("m:2-3=beac,i:4-19,i:20-21,i:22-23,p:24-24,d:25-25");
        BeaconTransmitter beaconTransmitter = new BeaconTransmitter(getApplicationContext(), beaconParser);
        beaconTransmitter.startAdvertising(beacon);
    }
    private void onCreateUserBeacon2(String value){
        String stringToTransmit = value;
        byte[] stringToTransmitAsAsciiBytes = stringToTransmit.getBytes(StandardCharsets.US_ASCII);
        Beacon beacon = new Beacon.Builder()
                .setId1(Identifier.fromBytes(stringToTransmitAsAsciiBytes, 0, 11, false).toString())
                //.setId2(Identifier.fromBytes(stringToTransmitAsAsciiBytes, 0, 4, false).toString())
                .setId2("3")
                .setId3("2")
                .setManufacturer(0x0118)
                .setTxPower(-59)
                .setDataFields(Arrays.asList(new Long[] {255l}))
                .setBluetoothName(Identifier.fromBytes(stringToTransmitAsAsciiBytes, 0, 5, false).toString())
                .build();

        BeaconParser beaconParser = new BeaconParser()
                .setBeaconLayout("m:2-3=beac,i:4-19,i:20-21,i:22-23,p:24-24,d:25-25");
        BeaconTransmitter beaconTransmitter = new BeaconTransmitter(getApplicationContext(), beaconParser);
        beaconTransmitter.startAdvertising(beacon);
    }
    private void logToDisplay2(final String line) {
        runOnUiThread(new Runnable() {
            public void run() {
                EditText editText = (EditText)RangingActivity.this.findViewById(R.id.rangingText);
                editText.append(line+"\n");
            }
        });
    }

    public void getInfetcted(final String mobile){
        //this.mobile=mobile;
       String personStatus;
        mediaPlayer = MediaPlayer.create(this, R.raw.alarm);
        RequestQueue queue = Volley.newRequestQueue(this);
        // String url ="https://samples.openweathermap.org/data/2.5/weather?lat=35&lon=139&appid=b6907d289e10d714a6e88b30761fae22";
        // String url="https://inzone19.000webhostapp.com/index.php?mobile=33767885735";
        String url="https://inzone19.000webhostapp.com/index.php";
        //  StringRequest stringRequest = new StringRequest(Request.Method.GET, url,        new Response.Listener<String>() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            /**
             * Called when a response is received.
             *
             * @param response
             */
            @Override
            public void onResponse(String response) {
                Log.i("entro"," work");
                String resultQuery=response.trim();

                System.out.println(resultQuery);
                if(resultQuery.trim().equals("infected")) {
                    System.out.println("yes");
                    mediaPlayer.start();
                    lastInsertId = response.toString();
                    //System.out.println(lastInsertId); // returns the lastInsertId
                    //callback.onSuccess(lastInsertId);
                    }
                if(resultQuery.trim().equals("error")) {
                    System.out.println("yes");
                    //mediaPlayer.stop();
                    lastInsertId = response.toString();
                    //System.out.println(lastInsertId); // returns the lastInsertId
                    //callback.onSuccess(lastInsertId);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("Error","doesnt work");


            }
        }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params= new HashMap<>();
                // String mobile="33767885735";
                params.put("mobile",mobile.trim());
                // return super.getParams();
                return params;
            }
        };
        queue.add(stringRequest);


    }


}

